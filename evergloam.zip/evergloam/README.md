# Evergloam
Simple Social Network in Node.js, Koa.js, MongoDB, React.js stack

Backend: [https://www.youtube.com/watch?v=CMMaVwTmcr4](https://www.youtube.com/watch?v=CMMaVwTmcr4)

Frontend: [https://www.youtube.com/watch?v=CoRekeJsVyE](https://www.youtube.com/watch?v=CoRekeJsVyE)

Frontend (Hooks & Context): [https://www.youtube.com/watch?v=R7dW-2Do7Oc](https://www.youtube.com/watch?v=R7dW-2Do7Oc)
