const bodyParser = require('koa-bodyparser')

module.exports = bodyParser()
